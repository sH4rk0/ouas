const presentationData = {


    slides: [
        {
            title: "Slide1",
            state: "slide1",
            preview: "",
            code: ""
        },

        {
            title: "Slide1",
            state: "slide1",
            preview: "",
            code: ""
        }


    ]

}


const gameData = {

    assets: {
        spritesheets: [],

        images: [{ name: "bg", path: "assets/images/bg.jpg" },],

        sounds: [],

        bitmapfont: [
            // { name: "carrier_command", imgpath: "assets/fonts/carrier_command.png", xmlpath: "assets/fonts/carrier_command.xml" }
        ]

    },

    map: [],
    levels: []

}